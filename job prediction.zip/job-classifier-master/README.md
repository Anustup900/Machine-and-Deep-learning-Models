# Python algorithm that uses Machine learning to classify job listings into one of 23 categories

## Must use anaconda to run it
